import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/selection_provider.dart';
import '../widgets/ratio_slider.dart';

class TitleScreen extends StatefulWidget {
  const TitleScreen({super.key});

  @override
  State<TitleScreen> createState() => _TitleScreenState();
}

class _TitleScreenState extends State<TitleScreen> {
  // 드롭다운 옵션들
  final List<String> methodOptions = [
    '심리학',
    '사회학',
    '경영학',
    '마케팅',
    '교육학',
    'IT/기술',
    '의료/보건',
    '기타',
  ];

  final List<int> sampleSizeOptions = [10, 20, 30, 50, 100];

  final List<String> screeningRuleOptions = [
    '전체',
    '20대 이상',
    '직장인만',
    '특정 지역',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('AI Research Panel'),
        centerTitle: true,
        elevation: 0,
      ),
      body: Consumer<SelectionProvider>(
        builder: (context, provider, child) {
          final selection = provider.selection;

          return SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // 타이틀
                const Text(
                  '설문 조사 설정',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'AI 페르소나 기반 설문 시뮬레이션',
                  style: TextStyle(
                    fontSize: 16,
                    color: Colors.grey.shade600,
                  ),
                ),
                const SizedBox(height: 32),

                // 연구 방법/분야
                _buildSectionTitle('연구 분야'),
                const SizedBox(height: 8),
                _buildDropdown(
                  value: selection.method.isEmpty ? null : selection.method,
                  hint: '분야를 선택하세요',
                  items: methodOptions,
                  onChanged: (v) => provider.setMethod(v!),
                ),
                const SizedBox(height: 24),

                // 샘플 수
                _buildSectionTitle('샘플 수'),
                const SizedBox(height: 8),
                _buildDropdown(
                  value: selection.sampleSize,
                  hint: '샘플 수 선택',
                  items: sampleSizeOptions,
                  onChanged: (v) => provider.setSampleSize(v!),
                ),
                const SizedBox(height: 24),

                // 스크리닝 규칙
                _buildSectionTitle('스크리닝 규칙'),
                const SizedBox(height: 8),
                _buildDropdown(
                  value: selection.screeningRule.isEmpty
                      ? null
                      : selection.screeningRule,
                  hint: '규칙을 선택하세요',
                  items: screeningRuleOptions,
                  onChanged: (v) => provider.setScreeningRule(v!),
                ),
                const SizedBox(height: 32),

                // 성별 비율
                GenderRatioSlider(
                  maleRatio: selection.maleRatio,
                  onChanged: provider.setGenderRatio,
                ),
                const SizedBox(height: 32),

                // 연령대별 비율
                _buildSectionTitle('연령대별 비율'),
                const SizedBox(height: 16),
                ...selection.ageRatios.entries.map((entry) {
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 16),
                    child: RatioSlider(
                      label: _getAgeLabel(entry.key),
                      value: entry.value,
                      onChanged: (v) => provider.setAgeRatio(entry.key, v),
                    ),
                  );
                }),
                const SizedBox(height: 32),

                // 시작 버튼
                SizedBox(
                  width: double.infinity,
                  height: 56,
                  child: ElevatedButton(
                    onPressed: provider.isValid()
                        ? () => Navigator.pushNamed(context, '/persona')
                        : null,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blue,
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: const Text(
                      '페르소나 생성 시작',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 20),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Text(
      title,
      style: const TextStyle(
        fontSize: 16,
        fontWeight: FontWeight.w600,
      ),
    );
  }

  Widget _buildDropdown<T>({
    required T? value,
    required String hint,
    required List<T> items,
    required ValueChanged<T?> onChanged,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey.shade300),
        borderRadius: BorderRadius.circular(12),
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<T>(
          value: value,
          hint: Text(hint),
          isExpanded: true,
          items: items.map((item) {
            return DropdownMenuItem<T>(
              value: item,
              child: Text(item.toString()),
            );
          }).toList(),
          onChanged: onChanged,
        ),
      ),
    );
  }

  String _getAgeLabel(String key) {
    switch (key) {
      case '10s':
        return '10대';
      case '20s':
        return '20대';
      case '30s':
        return '30대';
      case '40s':
        return '40대';
      case '50s+':
        return '50대 이상';
      default:
        return key;
    }
  }
}
