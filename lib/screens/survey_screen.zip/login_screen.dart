import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:kakao_flutter_sdk_user/kakao_flutter_sdk_user.dart' as kakao;
import '../providers/user_provider.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen>
    with TickerProviderStateMixin {
  // 화면 상태: onboarding -> login -> signup1 -> signup2 -> signup3
  String _screenState = 'onboarding';

  // 애니메이션 컨트롤러
  late AnimationController _fadeController;
  late Animation<double> _fadeAnimation;

  // 회원가입 폼 컨트롤러
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _passwordConfirmController = TextEditingController();
  bool _obscurePassword = true;
  bool _obscurePasswordConfirm = true;

  // 관심분야 선택
  final List<String> _selectedInterests = [];
  final List<Map<String, dynamic>> _interestOptions = [
    {'icon': Icons.school, 'label': '과제 / 리포트 피드백'},
    {'icon': Icons.science, 'label': '논문 / 연구 및 설문데이터'},
    {'icon': Icons.business_center, 'label': '기획 / 제안서 리뷰'},
    {'icon': Icons.chat_bubble_outline, 'label': '관계 / 커뮤니케이션'},
    {'icon': Icons.psychology, 'label': '사고 정리 / 생각 검증'},
    {'icon': Icons.more_horiz, 'label': '기타'},
  ];

  @override
  void initState() {
    super.initState();
    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    );
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fadeController, curve: Curves.easeInOut),
    );

    // 온보딩 애니메이션 시작
    _startOnboarding();
  }

  void _startOnboarding() async {
    await Future.delayed(const Duration(milliseconds: 500));
    _fadeController.forward();

    // 3초 후 로그인 화면으로 전환
    await Future.delayed(const Duration(seconds: 3));
    if (mounted) {
      _fadeController.reverse().then((_) {
        if (mounted) {
          setState(() => _screenState = 'login');
          _fadeController.forward();
        }
      });
    }
  }

  @override
  void dispose() {
    _fadeController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    _passwordConfirmController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: AnimatedSwitcher(
          duration: const Duration(milliseconds: 500),
          child: _buildCurrentScreen(),
        ),
      ),
    );
  }

  Widget _buildCurrentScreen() {
    switch (_screenState) {
      case 'onboarding':
        return _buildOnboardingScreen();
      case 'login':
        return _buildLoginScreen();
      case 'signup1':
        return _buildSignup1Screen();
      case 'signup2':
        return _buildSignup2Screen();
      case 'signup3':
        return _buildSignup3Screen();
      default:
        return _buildLoginScreen();
    }
  }

  // 온보딩 화면: "누구의 의견이 궁금하신가요?"
  Widget _buildOnboardingScreen() {
    return FadeTransition(
      opacity: _fadeAnimation,
      child: Center(
        key: const ValueKey('onboarding'),
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Text(
            '누구의 의견이\n궁금하신가요?',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 32,
              fontWeight: FontWeight.bold,
              color: Colors.grey.shade800,
              height: 1.4,
            ),
          ),
        ),
      ),
    );
  }

  // 로그인 화면
  Widget _buildLoginScreen() {
    return FadeTransition(
      opacity: _fadeAnimation,
      child: SingleChildScrollView(
        key: const ValueKey('login'),
        padding: const EdgeInsets.all(32),
        child: Column(
          children: [
            const SizedBox(height: 80),

            // AIPA 한 줄 핵심 기능
            Text(
              'AI 페르소나에게 의견을 물어보세요',
              style: TextStyle(
                fontSize: 16,
                color: Colors.grey.shade600,
              ),
            ),
            const SizedBox(height: 24),

            // AIPA 로고
            Container(
              width: 100,
              height: 100,
              decoration: BoxDecoration(
                color: Colors.blue.shade600,
                borderRadius: BorderRadius.circular(24),
              ),
              child: const Icon(
                Icons.psychology,
                size: 56,
                color: Colors.white,
              ),
            ),
            const SizedBox(height: 16),
            const Text(
              'AIPA',
              style: TextStyle(
                fontSize: 36,
                fontWeight: FontWeight.bold,
                letterSpacing: 2,
              ),
            ),

            const SizedBox(height: 80),

            // Google 로그인 버튼
            _buildSocialLoginButton(
              icon: Icons.g_mobiledata,
              label: 'Google로 로그인',
              color: Colors.red.shade600,
              onTap: () => _socialLogin('google'),
            ),
            const SizedBox(height: 12),

            // 카카오 로그인 버튼
            _buildSocialLoginButton(
              icon: Icons.chat_bubble,
              label: '카카오로 로그인',
              color: const Color(0xFFFEE500),
              textColor: Colors.black87,
              onTap: () => _socialLogin('kakao'),
            ),
            const SizedBox(height: 12),

            // 회원가입 버튼
            _buildOutlinedButton(
              label: '이메일로 회원가입',
              onTap: () {
                setState(() => _screenState = 'signup1');
              },
            ),
            const SizedBox(height: 12),

            // 게스트로 시작
            _buildOutlinedButton(
              label: '게스트로 시작',
              onTap: () => _guestLogin(),
            ),
          ],
        ),
      ),
    );
  }

  // 회원가입 Step 1: 기본 계정 생성
  Widget _buildSignup1Screen() {
    return SingleChildScrollView(
      key: const ValueKey('signup1'),
      padding: const EdgeInsets.all(32),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 40),

          // 뒤로가기
          IconButton(
            icon: const Icon(Icons.arrow_back),
            onPressed: () => setState(() => _screenState = 'login'),
          ),
          const SizedBox(height: 20),

          // 진행 표시
          _buildProgressIndicator(1),
          const SizedBox(height: 40),

          // 이메일
          TextField(
            controller: _emailController,
            keyboardType: TextInputType.emailAddress,
            decoration: InputDecoration(
              labelText: '이메일',
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
          ),
          const SizedBox(height: 16),

          // 비밀번호
          TextField(
            controller: _passwordController,
            obscureText: _obscurePassword,
            decoration: InputDecoration(
              labelText: '비밀번호',
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              suffixIcon: IconButton(
                icon: Icon(
                  _obscurePassword ? Icons.visibility_off : Icons.visibility,
                ),
                onPressed: () =>
                    setState(() => _obscurePassword = !_obscurePassword),
              ),
            ),
          ),
          const SizedBox(height: 16),

          // 비밀번호 확인
          TextField(
            controller: _passwordConfirmController,
            obscureText: _obscurePasswordConfirm,
            decoration: InputDecoration(
              labelText: '비밀번호 확인',
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              suffixIcon: IconButton(
                icon: Icon(
                  _obscurePasswordConfirm
                      ? Icons.visibility_off
                      : Icons.visibility,
                ),
                onPressed: () => setState(
                    () => _obscurePasswordConfirm = !_obscurePasswordConfirm),
              ),
            ),
          ),
          const SizedBox(height: 40),

          // 다음 버튼
          SizedBox(
            width: double.infinity,
            height: 56,
            child: ElevatedButton(
              onPressed: _validateAndGoToStep2,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.grey.shade700,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              child: const Text(
                '다음',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // 회원가입 Step 2: 관심분야 선택
  Widget _buildSignup2Screen() {
    return SingleChildScrollView(
      key: const ValueKey('signup2'),
      padding: const EdgeInsets.all(32),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 40),

          // 뒤로가기
          IconButton(
            icon: const Icon(Icons.arrow_back),
            onPressed: () => setState(() => _screenState = 'signup1'),
          ),
          const SizedBox(height: 20),

          // 진행 표시
          _buildProgressIndicator(2),
          const SizedBox(height: 40),

          // 안내 문구
          const Text(
            '맞춤형 페르소나 제안을 위해\n관심사를 선택해주세요',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              height: 1.4,
            ),
          ),
          const SizedBox(height: 32),

          // 관심분야 옵션들
          ..._interestOptions.map((option) => _buildInterestOption(option)),

          const SizedBox(height: 40),

          // 완료 버튼
          SizedBox(
            width: double.infinity,
            height: 56,
            child: ElevatedButton(
              onPressed: () => setState(() => _screenState = 'signup3'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.grey.shade700,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              child: const Text(
                '완료',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // 회원가입 Step 3: 완료
  Widget _buildSignup3Screen() {
    // 자동으로 회원가입 처리 후 홈으로 이동
    Future.delayed(const Duration(seconds: 2), () {
      if (mounted && _screenState == 'signup3') {
        _completeSignup();
      }
    });

    return Center(
      key: const ValueKey('signup3'),
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.check_circle_outline,
              size: 80,
              color: Colors.blue.shade600,
            ),
            const SizedBox(height: 32),
            const Text(
              '이제 당신을 위한\n패널들이\n준비되었습니다.',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
                height: 1.5,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // 진행 표시 위젯
  Widget _buildProgressIndicator(int step) {
    return Row(
      children: [
        _buildProgressDot(1, step),
        Expanded(child: _buildProgressLine(step >= 2)),
        _buildProgressDot(2, step),
        Expanded(child: _buildProgressLine(step >= 3)),
        _buildProgressDot(3, step),
      ],
    );
  }

  Widget _buildProgressDot(int dotStep, int currentStep) {
    final isActive = dotStep <= currentStep;
    return Container(
      width: 12,
      height: 12,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: isActive ? Colors.blue.shade600 : Colors.grey.shade300,
      ),
    );
  }

  Widget _buildProgressLine(bool isActive) {
    return Container(
      height: 2,
      color: isActive ? Colors.blue.shade600 : Colors.grey.shade300,
    );
  }

  // 소셜 로그인 버튼
  Widget _buildSocialLoginButton({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
    Color? textColor,
  }) {
    return SizedBox(
      width: double.infinity,
      height: 56,
      child: ElevatedButton.icon(
        onPressed: onTap,
        icon: Icon(icon),
        label: Text(label),
        style: ElevatedButton.styleFrom(
          backgroundColor: color,
          foregroundColor: textColor ?? Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
      ),
    );
  }

  // 아웃라인 버튼
  Widget _buildOutlinedButton({
    required String label,
    required VoidCallback onTap,
  }) {
    return SizedBox(
      width: double.infinity,
      height: 56,
      child: OutlinedButton(
        onPressed: onTap,
        style: OutlinedButton.styleFrom(
          side: BorderSide(color: Colors.grey.shade400),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
        child: Text(
          label,
          style: TextStyle(
            fontSize: 16,
            color: Colors.grey.shade700,
          ),
        ),
      ),
    );
  }

  // 관심분야 옵션 위젯
  Widget _buildInterestOption(Map<String, dynamic> option) {
    final isSelected = _selectedInterests.contains(option['label']);
    return GestureDetector(
      onTap: () {
        setState(() {
          if (isSelected) {
            _selectedInterests.remove(option['label']);
          } else {
            _selectedInterests.add(option['label']);
          }
        });
      },
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: isSelected ? Colors.blue.shade50 : Colors.white,
          border: Border.all(
            color: isSelected ? Colors.blue.shade400 : Colors.grey.shade300,
          ),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          children: [
            Icon(
              option['icon'],
              color: isSelected ? Colors.blue.shade600 : Colors.grey.shade600,
            ),
            const SizedBox(width: 12),
            Text(
              option['label'],
              style: TextStyle(
                fontSize: 16,
                color: isSelected ? Colors.blue.shade700 : Colors.grey.shade700,
                fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
              ),
            ),
            const Spacer(),
            if (isSelected)
              Icon(Icons.check, color: Colors.blue.shade600, size: 20),
          ],
        ),
      ),
    );
  }

  void _validateAndGoToStep2() {
    if (_emailController.text.isEmpty || !_emailController.text.contains('@')) {
      _showError('유효한 이메일을 입력해주세요');
      return;
    }
    if (_passwordController.text.length < 6) {
      _showError('비밀번호는 6자 이상이어야 합니다');
      return;
    }
    if (_passwordController.text != _passwordConfirmController.text) {
      _showError('비밀번호가 일치하지 않습니다');
      return;
    }
    setState(() => _screenState = 'signup2');
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  Future<void> _completeSignup() async {
    try {
      // UserProvider를 통해 회원가입 (Firebase Auth + Firestore 저장)
      final userProvider = Provider.of<UserProvider>(context, listen: false);
      final success = await userProvider.signUp(
        _emailController.text.trim(),
        _passwordController.text,
        _emailController.text.split('@').first, // 이름은 이메일 앞부분 사용
      );

      if (success && mounted) {
        // 관심사 업데이트
        if (_selectedInterests.isNotEmpty) {
          await userProvider.updateInterests(_selectedInterests);
        }
        Navigator.pushReplacementNamed(context, '/main');
      } else if (mounted) {
        _showError(userProvider.error ?? '회원가입 실패');
        setState(() => _screenState = 'signup1');
      }
    } catch (e) {
      if (mounted) {
        _showError('회원가입 중 오류가 발생했습니다');
        debugPrint('Signup Error: $e');
        setState(() => _screenState = 'signup1');
      }
    }
  }

  Future<void> _socialLogin(String provider) async {
    if (provider == 'google') {
      await _signInWithGoogle();
    } else if (provider == 'kakao') {
      await _signInWithKakao();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('$provider 로그인 (구현 예정)')),
      );
    }
  }

  Future<void> _signInWithGoogle() async {
    try {
      // Google Sign In 시작
      final GoogleSignInAccount? googleUser = await GoogleSignIn().signIn();

      if (googleUser == null) {
        // 사용자가 로그인 취소
        return;
      }

      // Google 인증 정보 가져오기
      final GoogleSignInAuthentication googleAuth =
          await googleUser.authentication;

      // Firebase credential 생성
      final credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );

      // Firebase로 로그인
      final userCredential =
          await FirebaseAuth.instance.signInWithCredential(credential);

      if (userCredential.user != null && mounted) {
        // UserProvider 업데이트 (Firestore에 저장)
        final userProvider = Provider.of<UserProvider>(context, listen: false);
        await userProvider.loginWithGoogle(
          userCredential.user!.uid,
          userCredential.user!.email ?? '',
          userCredential.user!.displayName ?? 'User',
          profileImage: userCredential.user!.photoURL,
        );

        Navigator.pushReplacementNamed(context, '/main');
      }
    } on FirebaseAuthException catch (e) {
      if (mounted) {
        _showError('로그인 실패: ${e.message}');
      }
    } catch (e) {
      if (mounted) {
        _showError('로그인 중 오류가 발생했습니다');
        debugPrint('Google Sign-In Error: $e');
      }
    }
  }

  Future<void> _signInWithKakao() async {
    try {
      kakao.OAuthToken token;

      // 카카오톡 설치 여부 확인
      if (await kakao.isKakaoTalkInstalled()) {
        // 카카오톡으로 로그인
        token = await kakao.UserApi.instance.loginWithKakaoTalk();
      } else {
        // 카카오 계정으로 로그인
        token = await kakao.UserApi.instance.loginWithKakaoAccount();
      }

      debugPrint('카카오 로그인 성공: ${token.accessToken}');

      // 사용자 정보 가져오기
      kakao.User kakaoUser = await kakao.UserApi.instance.me();

      if (mounted) {
        // UserProvider 업데이트 (Firestore에 저장)
        final userProvider = Provider.of<UserProvider>(context, listen: false);
        await userProvider.loginWithKakao(
          kakaoUser.id.toString(),
          kakaoUser.kakaoAccount?.email ?? '',
          kakaoUser.kakaoAccount?.profile?.nickname ?? 'User',
          profileImage: kakaoUser.kakaoAccount?.profile?.profileImageUrl,
        );

        Navigator.pushReplacementNamed(context, '/main');
      }
    } catch (e) {
      if (mounted) {
        _showError('카카오 로그인 중 오류가 발생했습니다');
        debugPrint('Kakao Sign-In Error: $e');
      }
    }
  }

  void _guestLogin() {
    // 게스트로 바로 메인 화면 이동
    Navigator.pushReplacementNamed(context, '/main');
  }
}
