import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/user_provider.dart';

class MainMenuScreen extends StatefulWidget {
  const MainMenuScreen({super.key});

  @override
  State<MainMenuScreen> createState() => _MainMenuScreenState();
}

class _MainMenuScreenState extends State<MainMenuScreen> {
  String? _selectedPersonaTemplate;
  bool _isLoading = false;

  // 페르소나 템플릿 목록
  final List<Map<String, dynamic>> _personaTemplates = [
    {
      'id': 'professor',
      'icon': Icons.school,
      'name': 'AI 교수님',
      'description': '과제, 쪽지시험 등 교수님의\n피드백이 필요한가요?',
      'color': Colors.indigo,
    },
    {
      'id': 'researcher',
      'icon': Icons.bar_chart,
      'name': 'AI 리서치 패널',
      'description': '사람들의 반응이\n궁금한가요?',
      'color': Colors.teal,
    },
    {
      'id': 'planner',
      'icon': Icons.business_center,
      'name': 'AI 기획 전문가',
      'description': '내가 작성한 기획안, 전문가\n눈에는 어떻게 보일까요?',
      'color': Colors.orange,
    },
    {
      'id': 'peer',
      'icon': Icons.people,
      'name': 'AI 동나이대 패널',
      'description': '이 사진이나 글,\n내 친구들은 어떻게 느낄까요?',
      'color': Colors.pink,
    },
  ];

  // 로딩 중 이탈 방지 멘트
  final List<String> _loadingMessages = [
    '생성된 AI 페르소나, 옷 입는 중...',
    '거울 앞에서 말투 연습 중...',
    '커피 한 잔 하며 생각 정리 중...',
    '등장 전에 숨 한 번 고르는 중...',
    '당신의 질문을 기다리는 중...',
  ];

  int _currentMessageIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        actions: [
          IconButton(
            icon: Icon(Icons.settings, color: Colors.grey.shade700),
            onPressed: () => _showSettingsMenu(context),
          ),
        ],
      ),
      body: _isLoading ? _buildLoadingScreen() : _buildMainContent(),
    );
  }

  Widget _buildMainContent() {
    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // 메인 타이틀
            Text(
              '누구의 의견이 궁금한가요?',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Colors.grey.shade800,
              ),
            ),
            const SizedBox(height: 32),

            // 페르소나 템플릿 횡스크롤
            SizedBox(
              height: 180,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: _personaTemplates.length,
                itemBuilder: (context, index) {
                  final template = _personaTemplates[index];
                  return _buildPersonaCard(template);
                },
              ),
            ),
            const SizedBox(height: 32),

            // 새 페르소나 생성 버튼
            SizedBox(
              width: double.infinity,
              height: 56,
              child: ElevatedButton(
                onPressed: _selectedPersonaTemplate != null
                    ? () => _startWithNewPersona()
                    : null,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.grey.shade800,
                  foregroundColor: Colors.white,
                  disabledBackgroundColor: Colors.grey.shade300,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                child: const Text(
                  '새 페르소나 생성',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
              ),
            ),
            const SizedBox(height: 12),

            // 구분선
            Row(
              children: [
                Expanded(child: Divider(color: Colors.grey.shade300)),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Text(
                    '혹은',
                    style: TextStyle(color: Colors.grey.shade500),
                  ),
                ),
                Expanded(child: Divider(color: Colors.grey.shade300)),
              ],
            ),
            const SizedBox(height: 12),

            // 기존 페르소나로 시작 버튼
            SizedBox(
              width: double.infinity,
              height: 56,
              child: OutlinedButton(
                onPressed: () => _showExistingPersonas(),
                style: OutlinedButton.styleFrom(
                  side: BorderSide(color: Colors.grey.shade400),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                child: Text(
                  '기존 페르소나로 시작',
                  style: TextStyle(
                    fontSize: 16,
                    color: Colors.grey.shade700,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 32),

            // 최근 프로젝트
            _buildRecentProjects(),
          ],
        ),
      ),
    );
  }

  Widget _buildPersonaCard(Map<String, dynamic> template) {
    final isSelected = _selectedPersonaTemplate == template['id'];
    final Color color = template['color'];

    return GestureDetector(
      onTap: () {
        setState(() {
          _selectedPersonaTemplate = template['id'];
        });
      },
      child: Container(
        width: 150,
        margin: const EdgeInsets.only(right: 12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: isSelected ? color.withOpacity(0.1) : Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isSelected ? color : Colors.grey.shade300,
            width: isSelected ? 2 : 1,
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // 아이콘
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: color.withOpacity(0.2),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(
                template['icon'],
                color: color,
                size: 24,
              ),
            ),
            const SizedBox(height: 12),
            // 이름
            Text(
              template['name'],
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.bold,
                color: isSelected ? color : Colors.grey.shade800,
              ),
            ),
            const SizedBox(height: 4),
            // 설명
            Expanded(
              child: Text(
                template['description'],
                style: TextStyle(
                  fontSize: 11,
                  color: Colors.grey.shade600,
                  height: 1.3,
                ),
              ),
            ),
            // 선택 표시
            if (isSelected)
              Align(
                alignment: Alignment.bottomRight,
                child: Icon(Icons.check_circle, color: color, size: 20),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildLoadingScreen() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const CircularProgressIndicator(),
          const SizedBox(height: 32),
          AnimatedSwitcher(
            duration: const Duration(milliseconds: 500),
            child: Text(
              _loadingMessages[_currentMessageIndex],
              key: ValueKey(_currentMessageIndex),
              style: TextStyle(
                fontSize: 16,
                color: Colors.grey.shade700,
              ),
              textAlign: TextAlign.center,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRecentProjects() {
    return Consumer<UserProvider>(
      builder: (context, userProvider, child) {
        final history = userProvider.history;

        if (history.isEmpty) return const SizedBox();

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  '최근 프로젝트',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.grey.shade800,
                  ),
                ),
                TextButton(
                  onPressed: () => Navigator.pushNamed(context, '/history'),
                  child: const Text('전체보기'),
                ),
              ],
            ),
            const SizedBox(height: 12),
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
                childAspectRatio: 1.5,
              ),
              itemCount: history.length > 4 ? 4 : history.length,
              itemBuilder: (context, index) {
                final project = history[index];
                return _buildProjectCard(project);
              },
            ),
          ],
        );
      },
    );
  }

  Widget _buildProjectCard(dynamic project) {
    return InkWell(
      onTap: () => Navigator.pushNamed(context, '/result'),
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.grey.shade100,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              project.title,
              style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w600,
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            const SizedBox(height: 4),
            Text(
              '${project.personaCount}명 페르소나',
              style: TextStyle(
                fontSize: 12,
                color: Colors.grey.shade600,
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _startWithNewPersona() async {
    setState(() => _isLoading = true);

    // 로딩 메시지 변경 타이머
    for (int i = 0; i < _loadingMessages.length; i++) {
      await Future.delayed(const Duration(milliseconds: 2000));
      if (mounted) {
        setState(() => _currentMessageIndex = i);
      }
    }

    if (mounted) {
      setState(() => _isLoading = false);
      Navigator.pushNamed(context, '/upload');
    }
  }

  void _showExistingPersonas() {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Container(
                    width: 40,
                    height: 4,
                    decoration: BoxDecoration(
                      color: Colors.grey.shade300,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                const Text(
                  '기존 프로젝트 선택',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 16),
                Consumer<UserProvider>(
                  builder: (context, userProvider, child) {
                    final history = userProvider.history;

                    if (history.isEmpty) {
                      return Padding(
                        padding: const EdgeInsets.all(32),
                        child: Center(
                          child: Text(
                            '저장된 프로젝트가 없습니다',
                            style: TextStyle(color: Colors.grey.shade600),
                          ),
                        ),
                      );
                    }

                    return ListView.builder(
                      shrinkWrap: true,
                      itemCount: history.length > 5 ? 5 : history.length,
                      itemBuilder: (context, index) {
                        final project = history[index];
                        return ListTile(
                          leading: CircleAvatar(
                            backgroundColor: Colors.blue.shade100,
                            child: Icon(Icons.folder, color: Colors.blue.shade600),
                          ),
                          title: Text(project.title),
                          subtitle: Text('${project.personaCount}명 페르소나'),
                          onTap: () {
                            Navigator.pop(context);
                            Navigator.pushNamed(context, '/upload');
                          },
                        );
                      },
                    );
                  },
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  void _showSettingsMenu(BuildContext context) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const SizedBox(height: 12),
              Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.grey.shade300,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(height: 20),
              ListTile(
                leading: const Icon(Icons.person_outline),
                title: const Text('프로필 설정'),
                onTap: () {
                  Navigator.pop(context);
                  Navigator.pushNamed(context, '/profile');
                },
              ),
              ListTile(
                leading: const Icon(Icons.history),
                title: const Text('히스토리'),
                onTap: () {
                  Navigator.pop(context);
                  Navigator.pushNamed(context, '/history');
                },
              ),
              ListTile(
                leading: const Icon(Icons.credit_card),
                title: const Text('구독 관리'),
                onTap: () {
                  Navigator.pop(context);
                  Navigator.pushNamed(context, '/subscription');
                },
              ),
              const Divider(),
              ListTile(
                leading: const Icon(Icons.logout, color: Colors.red),
                title: const Text('로그아웃', style: TextStyle(color: Colors.red)),
                onTap: () async {
                  Navigator.pop(context);
                  await context.read<UserProvider>().logout();
                  if (context.mounted) {
                    Navigator.pushReplacementNamed(context, '/login');
                  }
                },
              ),
              const SizedBox(height: 20),
            ],
          ),
        );
      },
    );
  }
}
