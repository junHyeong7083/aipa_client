import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/persona_provider.dart';
import '../providers/survey_provider.dart';

class SurveyScreen extends StatefulWidget {
  const SurveyScreen({super.key});

  @override
  State<SurveyScreen> createState() => _SurveyScreenState();
}

class _SurveyScreenState extends State<SurveyScreen> {
  bool _isRunning = false;
  int _currentStep = 0;
  final List<String> _steps = [
    'PDF 파싱 중...',
    '설문 구조화 중...',
    '일반 GPT 응답 생성 중...',
    '페르소나 응답 생성 중...',
    '결과 분석 중...',
  ];

  @override
  void initState() {
    super.initState();
    _startSurveySimulation();
  }

  Future<void> _startSurveySimulation() async {
    setState(() => _isRunning = true);

    // 더미 시뮬레이션 (각 단계 2초씩)
    for (int i = 0; i < _steps.length; i++) {
      await Future.delayed(const Duration(seconds: 2));
      if (mounted) {
        setState(() => _currentStep = i + 1);
      }
    }

    if (mounted) {
      setState(() => _isRunning = false);
      // 결과 화면으로 이동
      Navigator.pushReplacementNamed(context, '/result');
    }
  }

  @override
  Widget build(BuildContext context) {
    final personaProvider = context.watch<PersonaProvider>();
    final progress = _currentStep / _steps.length;

    return Scaffold(
      appBar: AppBar(
        title: const Text('설문 진행'),
        automaticallyImplyLeading: false,
      ),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // 진행률 원형 표시
            SizedBox(
              width: 150,
              height: 150,
              child: Stack(
                fit: StackFit.expand,
                children: [
                  CircularProgressIndicator(
                    value: progress,
                    strokeWidth: 10,
                    backgroundColor: Colors.grey.shade200,
                    valueColor: const AlwaysStoppedAnimation<Color>(Colors.blue),
                  ),
                  Center(
                    child: Text(
                      '${(progress * 100).toInt()}%',
                      style: const TextStyle(
                        fontSize: 32,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 40),

            // 현재 단계 표시
            Text(
              _currentStep < _steps.length
                  ? _steps[_currentStep]
                  : '완료!',
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w500,
              ),
            ),
            const SizedBox(height: 40),

            // 단계별 체크리스트
            ...List.generate(_steps.length, (index) {
              final isCompleted = index < _currentStep;
              final isCurrent = index == _currentStep;

              return Padding(
                padding: const EdgeInsets.symmetric(vertical: 8),
                child: Row(
                  children: [
                    Icon(
                      isCompleted
                          ? Icons.check_circle
                          : isCurrent
                              ? Icons.radio_button_checked
                              : Icons.radio_button_unchecked,
                      color: isCompleted
                          ? Colors.green
                          : isCurrent
                              ? Colors.blue
                              : Colors.grey,
                    ),
                    const SizedBox(width: 12),
                    Text(
                      _steps[index].replaceAll('...', ''),
                      style: TextStyle(
                        fontSize: 16,
                        color: isCompleted || isCurrent
                            ? Colors.black
                            : Colors.grey,
                        fontWeight:
                            isCurrent ? FontWeight.bold : FontWeight.normal,
                      ),
                    ),
                  ],
                ),
              );
            }),

            const SizedBox(height: 40),

            // 페르소나 수 표시
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.blue.shade50,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  _buildInfoItem('전체 페르소나', '${personaProvider.personas.length}명'),
                  _buildInfoItem('Junior', '${personaProvider.juniorPersonas.length}명'),
                  _buildInfoItem('Senior', '${personaProvider.seniorPersonas.length}명'),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoItem(String label, String value) {
    return Column(
      children: [
        Text(
          value,
          style: const TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: Colors.blue,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: TextStyle(
            fontSize: 14,
            color: Colors.grey.shade600,
          ),
        ),
      ],
    );
  }
}
